package com.nucleus.controler;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController 

{
	public final String page="loginpage";
	
	@RequestMapping("/target")
	public String request(HttpServletRequest request)
	{
		
		String target="admin";
		if(request.isUserInRole("ROLE_USER"))
			target="user1";
	
		
		return target; 
	
	}

	@RequestMapping("/loginpage")
	public String request()
	{
		return page; 
	
	}

}
