package com.nucleus.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CustomerDaoInterface;
import com.nucleus.entity.Customer;
import com.nucleus.userentity.User;


/*
this class is used for 
business logics 
all the methodes are same as the 
customer dao we are just calling 
the dao methodes from inside the methodes.*/


@Service
@Transactional
public class CustomerServiceImpI implements CustomerServiceInterface {
	
    @Autowired
	CustomerDaoInterface customerDao;

    @Override
	public void insertCustomer(Customer customer) 
	{
		customerDao.insertCustomer(customer);
		
	}

    @Override
	public Customer getCustomer(String customerCode) {
	Customer customer=	customerDao.getCustomer(customerCode);
		return customer;
	}

	@Override
	public void updateCustomer(Customer customer) {
		customerDao.updateCustomer(customer);
		
	}

	@Override
	public void deleteCustomer(String customerCode) {
		customerDao.deleteCustomer(customerCode);
		
	}

	@Override
	public List<Customer> displayAll() {
		List<Customer>lst=	customerDao.displayAll();
		return lst;
	}

	@Override
	public List<Customer> searchByName(String customerName) {
		List<Customer>lst=	customerDao.searchByName(customerName);
		return lst;
	}

	@Override
	public Customer searchByCode(String customerCode) {
		Customer customer=	customerDao.searchByCode(customerCode);
		return customer;
	}
/*
	@Override
	
	public void insertnewuser(User user) {
	customerDao.insertnewuser(user);	
		
	}

	@Override
	
	public void insertrole(User user, String role) 
	{
		customerDao.insertrole(user, role);
	}*/

	@Override
	public boolean checkCode(String name) {
	return customerDao.checkCode(name);
	}

	@Override
	public boolean checkCodeforupdate(String name) {
	
		return customerDao.checkCodeforupdate(name);
	}

	

}
