package com.nucleus.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.UserDaoInterface;
import com.nucleus.userentity.User;

@Service
@Transactional
public class UserServiceImpI implements UserServiceInterface
{

	 @Autowired
		UserDaoInterface userDao;
	
	@Override
	public void insertnewuser(User user) {
	userDao.insertnewuser(user);	
		
	}

	@Override
	public void insertrole(User user, String role) 
	{
		userDao.insertrole(user, role);
	}
}
