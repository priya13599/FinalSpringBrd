package com.nucleus.service;

import com.nucleus.userentity.User;

public interface UserServiceInterface 
{

	public void insertnewuser(User user);
	public void insertrole(User user,String role);
}
