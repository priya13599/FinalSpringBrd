package com.nucleus.dao;

import com.nucleus.userentity.User;

public interface UserDaoInterface 
{


	public void insertnewuser(User user);
	
	public void insertrole(User user,String role);
}
