package com.nucleus.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.nucleus.entity.Customer;
import com.nucleus.userentity.User;

@Repository
public class CustomerDAOImpI implements CustomerDaoInterface
{
	
	//QUERIES
	private static final String delete="delete Customer where customerCode=? ";
	private static final String displayall="from Customer";
	private static final String searchByname="from Customer where customerName=?";
	private static final String searchBycode="from Customer where customerCode=?";
	private static final String insertRoll="insert into  amita_role values(?,?)";
	private static final String check="from Customer where customerName =?";

	
	@Autowired
	SessionFactory sessionFactory;
	
	
	
	//to insert the customer data into database
	
	@Override
	public void insertCustomer(Customer customer) 
	{
		sessionFactory.getCurrentSession().persist(customer);

	}
	
	

	//to retrieve  the customer by customer code from the  database
	

	@Override
	public Customer getCustomer(String customerCode) 
	{
		Customer customer=(Customer) sessionFactory.getCurrentSession().get(Customer.class,customerCode);
		return customer;

	}
	
	

	// update  the customer by customer code in  the database

	@Override
	public void updateCustomer(Customer customer)
	{

		sessionFactory.getCurrentSession().update(customer);
	}

	
	
	
	//delete the customer by customer code from the database
	
	
	@Override
	public void deleteCustomer(String customerCode){

		Query query = sessionFactory.getCurrentSession().createQuery(delete);
		query.setParameter(0, customerCode);
		query.executeUpdate();

	}
	
	
	
	// to display the customer in a frame in the user screen from the  database

	@Override
	public List<Customer> displayAll()
	{
		Query query = sessionFactory.getCurrentSession().createQuery(displayall);
		List<Customer> customerList=query.list();
		return customerList;
	}
	
	
   //to view the customer by customer name from the database

	@Override
	public List<Customer> searchByName(String customerName) {
		Query query = sessionFactory.getCurrentSession().createQuery(searchByname);
		query.setParameter(0, customerName);
		ArrayList<Customer> cu =(ArrayList<Customer>)query.list();

		return cu;	}
	
	
	
	 //to view the customer based on customer code from the database
	
	@Override
	public Customer searchByCode(String customerCode) 
	{
		Query query = sessionFactory.getCurrentSession().createQuery(searchBycode);
		query.setParameter(0, customerCode);
		Customer customer=(Customer)query.uniqueResult();


		System.out.println(query);
		return customer;
	}
	
	
	
	
 //to check that whether the customer can be inserted in database or not by checking that customer already exist or not
	
	public boolean checkCode(String name) {
		Customer customer=(Customer) sessionFactory.getCurrentSession().get(Customer.class,name);
		if(customer == null)
		{
			return true;
		}
		
		
		return false;
	}

	
//to check whether update the customer can be done or not by checking the database
	
	
	public boolean checkCodeforupdate(String name) {
		
		
		Query query = sessionFactory.getCurrentSession().createQuery(check);	
		
		query.setParameter(0, name);
		
	       List<Customer> list=	query.list();
		
		if(list.isEmpty())
		{
			return false;
		}
		
		
		return true;
		
		
	}

/*
	//to insert a new user in the database
	

	@Override
	public void insertnewuser(User user) {

		sessionFactory.getCurrentSession().persist(user);

	}
	
	
   // to insert a new users role  in the  database
	
	 
	@Override
	public void insertrole(User user, String role) 
	{

		SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(insertRoll);
		query.setParameter(0, user.getUserName());
		query.setParameter(1, role);
		query.executeUpdate();

	}

	*/





}
