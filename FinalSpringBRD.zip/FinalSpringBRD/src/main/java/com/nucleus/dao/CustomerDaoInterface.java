package com.nucleus.dao;


import java.util.List;

import com.nucleus.entity.Customer;
import com.nucleus.userentity.User;



public interface CustomerDaoInterface 
{
	public void insertCustomer(Customer customer);
	public void updateCustomer(Customer customer);
	
	public Customer getCustomer(String customerCode);
	
	
	public void deleteCustomer(String customerCode);
	
	public List<Customer> displayAll();
	
	public List<Customer> searchByName(String customerName);
	
	public Customer searchByCode(String customerCode);
	
	public boolean checkCode(String name);
	
	public boolean checkCodeforupdate(String name);

	/*
	public void insertnewuser(User user);
	
	public void insertrole(User user,String role);*/
}
