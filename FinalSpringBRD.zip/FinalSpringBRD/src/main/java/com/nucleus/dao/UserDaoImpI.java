package com.nucleus.dao;

import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.userentity.User;

@Repository
public class UserDaoImpI implements UserDaoInterface


{


	@Autowired
	SessionFactory sessionFactory;
	
	private static final String insertRoll="insert into  amita_role values(?,?)";
	
	//to insert a new user in the database
	

	@Override
	public void insertnewuser(User user) 
	{

		sessionFactory.getCurrentSession().persist(user);

	}
	
	
   // to insert a new users role  in the  database
	
	 
	@Override
	public void insertrole(User user, String role) 
	{

		SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(insertRoll); //earlier insertroll
		query.setParameter(0, user.getUserName());
		query.setParameter(1, role);
		query.executeUpdate();

	}

	
}
