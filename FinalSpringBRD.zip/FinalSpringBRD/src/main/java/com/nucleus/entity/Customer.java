package com.nucleus.entity;







import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;




/*
this class belongs to the customers 
data members, all the data members can be set and retrieve 
by using this class*/








@Entity
@Table(name="NamanFinalBrdCustomer")
public class Customer 
{
 @Id
 @Length(min=1,max=10)
 @Column(name="CUSTOMERCODE",length=10)
 @Pattern(regexp="^[0-9]{1,10}$")

 private String customerCode;
 
 public String getCustomerCode() 
 {
	return customerCode;
 }


public void setCustomerCode(String customerCode)
{
	this.customerCode = customerCode;
}


public String getCustomerName() {
	return customerName;
}


public void setCustomerName(String customerName) {
	this.customerName = customerName;
}


public String getCustomerAddress() 
{
	return customerAddress;
}


public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}


public String getCustomerPinCode() {
	return customerPinCode;
}


public void setCustomerPinCode(String customerPinCode) {
	this.customerPinCode = customerPinCode;
}


public String getCustomerEmail() {
	return customerEmail;
}


public void setCustomerEmail(String customerEmail) {
	this.customerEmail = customerEmail;
}


public String getCustomerContactNumber() {
	return customerContactNumber;
}


public void setCustomerContactNumber(String customerContactNumber) {
	this.customerContactNumber = customerContactNumber;
}


public Date getRegistrationDate() {
	return registrationDate;
}


public void setRegistrationDate(Date registrationDate) {
	this.registrationDate = registrationDate;
}


public String getCreatedBy() {
	return createdBy;
}


public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}


public Date getModifiedDate() {
	return modifiedDate;
}


public void setModifiedDate(Date modifiedDate) {
	this.modifiedDate = modifiedDate;
}



 @Length(min=1,max=30)
 @Column(name="CUSTOMERNAME",length=30)
 private String customerName;
 
 
 @Length(min=1,max=100)

 @Column(name="CUSTOMERADDRESS",length=100)
 private String customerAddress;
 
 @Pattern(regexp="^[1-9][0-9]{5}$")
 @Length(min=6,max=6)
 @Column(name="CUSTOMERPINCODE",length=6)
 private String customerPinCode;
 
 @Pattern(regexp="^[a-zA-Z0-9_+&*-]+(?:[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9]+\\.)[a-zA-Z]{2,7}$")
 @Length(min=1,max=100)
 @Column(name="CUSTOMEREMAIL",length=100)
 private String customerEmail;
 
 
 @Length(min=1,max=20)
 @Column(name="CUSTOMERCONTACTNUMBER",length=20)
 private String customerContactNumber;
 
 
 @Column(name="REGISTRATIONDATE")
 private Date registrationDate;
 
 @Column(name="CREATEDBY",length=20)
 private String createdBy;
 
 
 @Column(name="MODIFIEDDATE")
 private Date modifiedDate;
 
}
