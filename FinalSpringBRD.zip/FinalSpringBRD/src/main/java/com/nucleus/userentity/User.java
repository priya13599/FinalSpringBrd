
package com.nucleus.userentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;






@Entity
@Table(name="amita_user")
public class User
{

	@Id
	 @Length(min=2,max=50)
	 @Column(length=50)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	 private String userName;
	 
	@Column(length=60,nullable=false)
	@Length(min=2,max=60)
	private String password;
	
	@Column(nullable=false)
	private int enabled;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	
	
	
	
	
	
	
	

}
