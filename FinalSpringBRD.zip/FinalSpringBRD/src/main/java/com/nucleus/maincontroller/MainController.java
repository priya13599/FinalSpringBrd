package com.nucleus.maincontroller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.nucleus.dao.CustomerDaoInterface;
import com.nucleus.entity.Customer;
import com.nucleus.service.CustomerServiceInterface;
import com.nucleus.service.UserServiceInterface;
import com.nucleus.userentity.User;
import com.nucleus.utility.PassEncoder;

@Controller
public class MainController 
{


	@Autowired
	//@Qualifier(value="CustomerServiceImpI")
	CustomerServiceInterface cs;
	
	@Autowired
	//@Qualifier(value="UserServiceImpI")
	UserServiceInterface us;

	@Autowired
	PassEncoder passEncoder;


	String page ="Insert";


	@RequestMapping("/Insert")                                  // To open Add Customer page
	public ModelAndView insertcustomer(Customer customer)

	{	

		return new ModelAndView("Insert"); 

	}


	@RequestMapping("/user1")                                  //To open User Page
	public String r()
	{
		return "user1";
	}

	
	@RequestMapping("/inserted")                             // To add a customer
	public ModelAndView getCustomer(@Valid Customer customer,BindingResult result,Authentication authentication,HttpServletRequest request)
	{
        ModelAndView mv=new ModelAndView(page);
		String code = customer.getCustomerCode();
		if(cs.checkCode(code))
		{
			if(result.hasErrors())
			{

				return mv;
			}
			else
			{
				long millis=System.currentTimeMillis();
				customer.setRegistrationDate(new java.sql.Date(millis));
				customer.setCreatedBy(authentication.getName());
				cs.insertCustomer(customer);
				mv= new ModelAndView("user1");
			}
			return mv;
		}
		else
		{
			mv.addObject("result","Customer code already exist");
			return mv;
		}
	
	}



	@RequestMapping("/Update")
	public ModelAndView  get(Customer customer)

	{

		return new ModelAndView("Update12"); 

	}
	@RequestMapping("/getcode")
	public ModelAndView  getcode(Customer customer ,HttpServletRequest request,ModelMap map)

	{
		
		String code = customer.getCustomerCode();
		ModelAndView mv= new ModelAndView("Update12");
		
		
		
		if(!(cs.checkCode(code)))
		{
		
		mv = new ModelAndView("Updating");
		Customer customer1=cs.getCustomer(customer.getCustomerCode());
		mv.addObject("customer1", customer1);

		return mv; 

	  }
		else
		{
			mv.addObject("result","Customer code does not  exist");
			return mv;
		}
	}

	@RequestMapping("/UpdatedCustomerData")
	public ModelAndView updatedCustomerData(@Valid Customer customer,BindingResult result,Authentication authentication)
	{
		
		ModelAndView mv= new ModelAndView("Updating");
		
		String code = customer.getCustomerCode();
		
		if(!(cs.checkCode(code)))
		{
		mv= new ModelAndView("user1");
		long millis=System.currentTimeMillis();
		customer.setModifiedDate(new java.sql.Date(millis));
		customer.setCreatedBy(authentication.getName());

		cs.updateCustomer(customer);
		return mv;
		}

		
		else
		{
			mv.addObject("result","Customer code does not  exist");
			return mv;
		}

	}


	@RequestMapping("/Delete")
	public ModelAndView  delete(Customer customer)

	{

		return new ModelAndView("Delete"); 

	}



	@RequestMapping("/deleterecord")
	public ModelAndView deletedata(Customer customer ,HttpServletRequest request)
	{
		
		ModelAndView mv = new ModelAndView("Delete");
		String code = customer.getCustomerCode();
		if(!(cs.checkCode(code)))
		  {	
			
		long millis=System.currentTimeMillis();
      
		mv = new ModelAndView("user1");
		
		cs.deleteCustomer(customer.getCustomerCode());

		return mv;

	       }
		else
		{
	          
			mv.addObject("result","Customer with this code does not exist ");
			return mv;
		}
		
	}

	@RequestMapping("/View")
	public ModelAndView  view(Customer customer)

	{

		return new ModelAndView("View"); 

	}

	@RequestMapping("/viewbycode")
	public ModelAndView viewbycode(Customer customer ,ModelMap map)
	{
		
		ModelAndView mv = new ModelAndView("View");
		
		String code = customer.getCustomerCode();
		
		if(!(cs.checkCode(code)))
		{
		
		long millis=System.currentTimeMillis();

	          mv =	new ModelAndView("viewing");


		customer=cs.searchByCode(customer.getCustomerCode());
		ArrayList<Customer> cu = new ArrayList<Customer>();
		cu.add(customer);


		mv.addObject("lists", cu);
		
		return mv;
		}
		else 
		{
			mv.addObject("result","Customer with this code does not exist ");
			return mv;
			
		}

	}


	@RequestMapping("/view1")
	public ModelAndView  view12(Customer customer)

	{

		return new ModelAndView("view1"); 

	}



	@RequestMapping("/viewwithname")
	public ModelAndView viewbyname(Customer customer ,HttpServletRequest request,ModelMap map)
	{
		
		ModelAndView mv = new ModelAndView("view1");
		
		String name = customer.getCustomerName();

		if(cs.checkCodeforupdate(name))
		{
		
		
		long millis=System.currentTimeMillis();

		 mv =	new ModelAndView("viewbyname");
		 	
		ArrayList<Customer> customer1= (ArrayList<Customer>) cs.searchByName(customer.getCustomerName());
		mv.addObject("lists", customer1);

		return mv;

	}
		else
		{
			mv.addObject("result","Customer with this Name does not exist ");
			return mv;
			
		}
	}



	@RequestMapping("/displayall")
	public ModelAndView  display(HttpServletRequest request)

	{


		List<Customer> customerList=cs.displayAll();
		return new ModelAndView("dynamic","customerList",customerList);



	}

	@RequestMapping("/insertbyadmin")
	public ModelAndView  userInsertion(User user)

	{

		return new ModelAndView("Userinsertion"); 

	}


	@RequestMapping("/newinserted")
	public ModelAndView  newinsertion(@Valid @ModelAttribute("user") User user ,HttpServletRequest request ,BindingResult result)

	{
		String pass=passEncoder.encoded(user.getPassword());
		int val=1;
		user.setEnabled(val);
		String role = "ROLE_USER";
		user.setPassword(pass);
		us.insertnewuser(user);
		us.insertrole(user, role);
        return new ModelAndView("admin");
	}
}
