package com.nucleus.utility;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


import org.springframework.stereotype.Component;


/*
this class is used to encrypt the 
users password..........

*/
@Component
public class PassEncoder 
{
	
	
	
	
	public String encoded(String pwd)
	{
		BCryptPasswordEncoder obj = new BCryptPasswordEncoder();
		pwd = obj.encode(pwd);
		return pwd;
		
	}
	
/*	public static void main(String[] args)
	{
		PassEncoder encoder=new PassEncoder();
		System.out.println(encoder.encoded("123"));
		
	}*/
	
	
	
}
